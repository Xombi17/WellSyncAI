export interface PatientRecord {
  id: string;
  name: string;
  age: number;
  type: 'adult' | 'child';
  parentName?: string;
  vaccinations: {
    name: string;
    date: string;
    status: 'completed' | 'pending' | 'overdue';
  }[];
  generalHealth: string;
  lastConsultation: string;
}

export const mockDatabase: PatientRecord[] = [
  {
    id: 'P001',
    name: 'Emma Johnson',
    age: 32,
    type: 'adult',
    vaccinations: [
      { name: 'Flu Shot', date: '2025-10-15', status: 'completed' },
      { name: 'COVID-19 Booster', date: '2024-11-01', status: 'completed' }
    ],
    generalHealth: 'Healthy, no chronic conditions. Reports occasional migraines.',
    lastConsultation: '2026-01-20'
  },
  {
    id: 'P002',
    name: 'Liam Johnson',
    age: 4,
    type: 'child',
    parentName: 'Emma Johnson',
    vaccinations: [
      { name: 'MMR (Measles, Mumps, Rubella)', date: '2023-05-10', status: 'completed' },
      { name: 'DTaP (Diphtheria, Tetanus, Pertussis)', date: '2026-06-01', status: 'pending' },
      { name: 'Polio', date: '2025-02-15', status: 'completed' }
    ],
    generalHealth: 'Growing well, meeting all developmental milestones. Mild asthma triggered by cold weather.',
    lastConsultation: '2026-03-10'
  },
  {
    id: 'P003',
    name: 'Noah Williams',
    age: 7,
    type: 'child',
    parentName: 'Sarah Williams',
    vaccinations: [
      { name: 'Varicella (Chickenpox)', date: '2020-08-22', status: 'completed' },
      { name: 'Flu Shot', date: '2025-09-30', status: 'overdue' }
    ],
    generalHealth: 'Generally healthy. Recovered from a minor ear infection last month.',
    lastConsultation: '2026-02-28'
  },
  {
    id: 'P004',
    name: 'Sarah Williams',
    age: 35,
    type: 'adult',
    vaccinations: [
      { name: 'Tetanus Booster', date: '2018-04-12', status: 'overdue' }
    ],
    generalHealth: 'Managing type 2 diabetes with diet and exercise. Blood pressure is normal.',
    lastConsultation: '2026-04-05'
  }
];

export function searchPatientRecords(query: string): PatientRecord[] {
  const lowerQuery = query.toLowerCase();
  return mockDatabase.filter(patient => 
    patient.name.toLowerCase().includes(lowerQuery) ||
    (patient.parentName && patient.parentName.toLowerCase().includes(lowerQuery)) ||
    patient.generalHealth.toLowerCase().includes(lowerQuery) ||
    patient.vaccinations.some(v => v.name.toLowerCase().includes(lowerQuery))
  );
}
